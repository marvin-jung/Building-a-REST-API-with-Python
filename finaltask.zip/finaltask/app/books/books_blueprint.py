from flask import Blueprint, jsonify, request
from app import db
from models import Book


books_blueprint = Blueprint('books_blueprint', __name__, url_prefix="/books")


@books_blueprint.route("", methods=["GET"])
def get_books():
    books = Book.query.all()
    serialised = {
        "books": [book.serialised() for book in books]
    }

    return jsonify(serialised)


@books_blueprint.route("/<int:uid>", methods=["GET"])
def get_book(uid):
    book = Book.query.get(uid)
    return jsonify(book.serialised())


@books_blueprint.route("", methods=["POST"])
def post_book():
    request_json = request.get_json()
    try:
        title = request_json['title']
        author = request_json['author']
    except KeyError:
        return "Please provide a title and author.", 400

    new_book = Book(title = title, author = author)
    
    db.session.add(new_book)
    db.session.commit()

    return jsonify(new_book.serialised())



